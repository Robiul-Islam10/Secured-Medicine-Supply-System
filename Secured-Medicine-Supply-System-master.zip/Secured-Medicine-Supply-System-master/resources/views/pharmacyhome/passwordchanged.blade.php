<!DOCTYPE html>
@extends('pharmacylayout')
<html>
<head>
	<title>Password Changed</title>
</head>
<body>
	@section('passwordchanged')
	<div id="admininputdiv">
		<br><br><br>
		<table align="center" style="width: 90%">
			<tr>
				<td align="center">Changed Has Been Saved</td>
			</tr>
		</table>	
	</div>
	@endsection
</body>
</html>