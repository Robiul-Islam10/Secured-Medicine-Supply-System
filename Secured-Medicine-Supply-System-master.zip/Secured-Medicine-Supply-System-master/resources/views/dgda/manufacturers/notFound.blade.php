<!DOCTYPE html>
<html>
<head>
	<title>DGDA|PHARMACIES</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="alert alert-success alert-block">
		<button type="button" class="close" data-dismiss="alert">×</button>	
        <strong>
        	<a href="{{ URL::previous() }}" style="text-decoration: none; color: inherit;"> Not Found</a>
        </strong>
	</div>	
</body>
</html>
