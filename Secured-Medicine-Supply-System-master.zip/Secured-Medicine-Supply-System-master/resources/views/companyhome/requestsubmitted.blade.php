@extends('companylayout')
<!DOCTYPE html>
<html>
<head>
	<title>Request Submitted</title>
</head>
<body>
	@section('requestsubmitted')
	<div id="admininputdiv">
		<br><br><br>
		<table align="center" style="width: 90%">
			<tr>
				<td align="center">
					Product Release Request Has Been Submitted
				</td>
			</tr>
		</table>
	</div>
	@endsection	
</body>
</html>